>>> Book.objects.all()
# <QuerySet [<Book: 1984>]>